# Blog App Monolith

Endpoint 
>  http://localhost:8081/

H2 Console 
>  http://localhost:8081/h2-console

## Architecture Diagram

![architecture](architecture.png)

## ER Diagram

![er-diagram](er-diagram.png)

## REST Architecture

![rest](rest.webp)